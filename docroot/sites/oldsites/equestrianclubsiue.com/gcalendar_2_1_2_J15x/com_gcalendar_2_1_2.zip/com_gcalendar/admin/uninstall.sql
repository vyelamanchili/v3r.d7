DROP TABLE IF EXISTS `#__gcalendar`;
