<?php
/*----------------------------------------------------------------------
#Youjoomla  Image Slider v2.0
# ----------------------------------------------------------------------
# Copyright (C) 2007 You Joomla. All Rights Reserved.
# Coded by: Dmitry Ryshkin
# License: Copyright Youjoomla.com
# Website: http://www.youjoomla.com
------------------------------------------------------------------------*/
defined('_JEXEC') or die('Direct Access to this location is not allowed.');





  $class_fx=$params->get('moduleclass_sfx');

  $swidth=$params->get('swidth');
  $sheight=$params->get('sheight');

  $sorient=$params->get('sorient');
  $start_slide=$params->get('start_slide');
  $type_slider=$params->get('type_slider');
  $stime=$params->get('stime');
  $sduration=$params->get('sduration');
  $smenu=$params->get('smenu');
  $balons=$params->get('balons');

 

  
  
  echo "<!-- http://www.Youjoomla.com  Image Slider for Joomla 1.5 starts here -->	";
  $linktag="<link rel='stylesheet' type='text/css' href='". JURI::base()."/modules/mod_image_slider/mod_image_slider.css'/>\n";
  $linktag.="<script type='text/javascript' src='".JURI::base()."/media/system/js/mootools.js'></script>\n";
  $linktag.="<script type='text/javascript' src='". JURI::base()."/modules/mod_image_slider/slide.js'></script>\n";


  $mainframe->addCustomHeadTag($linktag);


  $now 		    = date('Y-m-d');
  $access 	    = !$mainframe->getCfg( 'shownoauth' );
  if(function_exists("database::getNullDate")){
    $nullDate = $database->getNullDate();
    } else {
     $nullDate = "0000-00-00 00:00:00";
}                       //$nullDate 	= $database->getNullDate();
  $my           = $mainframe->getUser();
  $gid          = intval($my->gid);
  
 $slide_option=array();
  for ($i=0;$i<10;$i++)
  {
    $slide_option[$i]["title"]=$params->get('slide_title_'.($i+1));
    $slide_option[$i]["image"]=$params->get('slide_image_'.($i+1));
    $slide_option[$i]["link"]=$params->get('slide_link_'.($i+1));
    $slide_option[$i]["open"]=$params->get('slide_open_'.($i+1));
	$slide_option[$i]["description"]=$params->get('slide_description_'.($i+1));
  }
  if ($balons==0)
  {
  echo "";
    }

  echo "<div id='images_slide' class='".$class_fx."slide' style=\"width: ".$swidth."px; height: ".$sheight."px;\">\n";

  if ($sorient==0)
  {
    $swidth_all=$swidth;
    $sheight_all=$sheight*10;
  }else
  {
    $swidth_all=$swidth*10;
    $sheight_all=$sheight;
  }
  echo "<div style=\"width: ".$swidth_all."px; height: ".$sheight_all."px;overflow: hidden;\">\n";

   for ($i=0;$i<10;$i++)
  {
    if (($slide_option[$i]["image"]!=-1)&&($slide_option[$i]["image"]!=""))
    {
      //-- Start slide ---
      echo "<div style=\"width: ".$swidth."px; height: ".$sheight."px;overflow: hidden;\">\n";

      if ($slide_option[$i]["link"]!="")
      {
        if ($slide_option[$i]["open"]==0)
        {
          echo "<a href=\"".$slide_option[$i]["link"]."\" target=\"_blank\">\n";
        }else
        {
          echo "<a href=\"".$slide_option[$i]["link"]."\" target=\"_self\">\n";
        }
      }

      if (($slide_option[$i]["title"]!="")&&($balons==0))
      {
        echo "<img src=\"". JURI::base()."/images/upload_slides/".$slide_option[$i]["image"]."\"align=\"middle\" alt=\"\" border=\"0\" class=\"youjoomlatip\" title=\"".$slide_option[$i]["title"]." :: ".$slide_option[$i]["description"]."\"  />\n";
      }else
      {
       echo "<img src=\"". JURI::base()."/images/upload_slides/".$slide_option[$i]["image"]."\" align=\"right\" alt=\"\" border=\"0\" title=\"".$slide_option[$i]["title"]."\"/>\n";
      }


      if ($slide_option[$i]["link"]!="")
      {
      echo "</a>\n";
      }
      echo "</div>\n";
      //-- End slide ---
    }
  }

  echo "</div>\n";
  echo "</div>\n";

  if ($start_slide==0)
  {
    $direction="forward";
  }else
  {
    $direction="pause";
  }
  if ($type_slider==0)
  {
    $type="fade";
  }else
  {
    if ($type_slider==1)
    {

      $type="scroll";
    }else
    {
      $type="scrollfade";
    }
  }


  echo "<script type='text/javascript'>\n";
  echo "var  fns_slider = new SimpleSlide(\"images_slide\",{type: \"".$type."\", direction: \"".$direction."\", auto: \"loop\", time: ".$stime.", duration: ".$sduration."});\n";
  echo "var type_slider='scroll';\n";
  echo "$('images_slide').addEvent('mouseenter', function(){fns_slider.pause();});\n";
  echo "$('images_slide').addEvent('mouseleave', function(){fns_slider.run();});\n";
  echo "</script>\n";

  if ($smenu==0)
  {
    echo "<a class=\"".$class_fx."slide_menu\" onclick='javascript: fns_slider.prev(type_slider);'>\n";
    echo "<img src=\"". JURI::base()."/modules/mod_image_slider/img/prev.gif\" alt=\"Prev\" border=\"0\"/>\n";
    echo "</a>\n";
    echo "&nbsp;\n";
    echo "<a class=\"".$class_fx."slide_menu\" onclick='javascript: fns_slider.next(type_slider);'>\n";
    echo "<img src=\"". JURI::base()."/modules/mod_image_slider/img/next.gif\" alt=\"Next\" border=\"0\"/>\n";
    echo "</a>\n";
    echo "&nbsp;\n";
    echo "<a class=\"".$class_fx."slide_menu\" onclick='javascript: fns_slider.pause();'>\n";
    echo "<img src=\"". JURI::base()."/modules/mod_image_slider/img/pause.gif\" alt=\"Pause\" border=\"0\"/>\n";
    echo "</a>\n";
    echo "&nbsp;\n";
    echo "<a class=\"".$class_fx."slide_menu\" onclick='javascript: fns_slider.run();'>\n";
    echo "<img src=\"". JURI::base()."/modules/mod_image_slider/img/play.gif\" alt=\"Play\" border=\"0\"/>\n";
    echo "</a>\n";
    echo "&nbsp;&nbsp;&nbsp;\n";
    echo "<a class=\"".$class_fx."slide_menu\" onclick='javascript: type_slider=\"scroll\";'>\n";
    echo "<img src=\"". JURI::base()."/modules/mod_image_slider/img/t1.gif\" alt=\"Scroll\" border=\"0\"/>\n";
    echo "</a>\n";
    echo "&nbsp;\n";
    echo "<a class=\"".$class_fx."slide_menu\" onclick='javascript: type_slider=\"fade\";'>\n";
    echo "<img src=\"". JURI::base()."/modules/mod_image_slider/img/t2.gif\" alt=\"Fade\" border=\"0\"/>\n";
    echo "</a>\n";
    echo "&nbsp;\n";
    echo "<a class=\"".$class_fx."slide_menu\" onclick='javascript: type_slider=\"scrollfade\";'>\n";
    echo "<img src=\"". JURI::base()."/modules/mod_image_slider/img/t3.gif\" alt=\"ScrollFade\" border=\"0\"/>\n";
    echo "</a>\n";
  }
  /*
    <param name="img_width" type="text" default="75" label="Image Width (px)" description="Image Width (px)" />
    <param name="img_height" type="text" default="75" label="Image Height (px)" description="Image Height (px)" />
  */
?>